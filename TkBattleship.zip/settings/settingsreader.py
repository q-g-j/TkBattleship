from models.settings import Settings


class SettingsReader:
    def __init__(self):
        pass

    def read(self) -> Settings:
        settings = Settings()

        return settings
