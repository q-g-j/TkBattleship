class EventHandlerBase:
    def execute(self, *args):
        pass
