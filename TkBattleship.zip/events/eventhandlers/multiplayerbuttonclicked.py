from events.eventhandlers.eventhandlerbase import EventHandlerBase


class MultiplayerButtonClickedEventHandler(EventHandlerBase):
    def __init__(self) -> None:
        pass

    def execute(self):
        pass
