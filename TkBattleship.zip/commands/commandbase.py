class CommandBase:
    def execute(self, *args):
        pass
