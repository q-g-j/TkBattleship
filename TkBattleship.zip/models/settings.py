class Settings:
    def __init__(self, cell_size: int = 40) -> None:
        self.cell_size = cell_size
